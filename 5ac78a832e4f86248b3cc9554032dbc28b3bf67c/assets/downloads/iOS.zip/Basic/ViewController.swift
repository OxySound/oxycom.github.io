import Oxy
import UIKit
import AVFoundation
 
class ViewController: UIViewController, oxyDelegate  {
   
    @IBOutlet weak var wipbtn: UIButton!

    let oxyManager = Oxy.instance()
    
    let amax:Float = -110  //Set Distance to measure
    
    
    //MARK: Flow control of payload
    var tog:Bool = false
    var payload:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Assign delegate
       oxyManager?.delegate=self

        // Start engine
       oxyManager!.listen()

    }
    //MARK: Still processing audio push to new thread
    func oxyId(with oxy_id: String!) {
        if(self.payload != oxy_id){
            self.payload = oxy_id
            self.tog = true
        }
        DispatchQueue.main.async {
            
            
                 self.view.backgroundColor = self.random()
                if(self.tog == true) {
                             /* Prevent
                           self.tog = false
                            */
                    
                    self.view.backgroundColor = self.random()
                         }

                if(self.oxyManager!.distanceVol() < self.amax ) {
                    print(self.oxyManager!.distanceVol())
                    self.showToast("Move device closer")
                    self.view.backgroundColor =
                        // Red
                        self.UIColorFromHex(rgbValue: 0xD61E1E,alpha: 1)
                }else{
                        self.showToast("Device within range")
                        // Green
                        self.view.backgroundColor = self.UIColorFromHex(rgbValue: 0x228B22,alpha: 1)
                }
        }
}
    func random() -> UIColor {
        return UIColor(red: .random(in: 0...1),
                       green: .random(in: 0...1),
                       blue: .random(in: 0...1),
                       alpha: 1.0)
    }

   
    // Helpers
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0

        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    

    func toggleTorch(on: Bool) {
        guard
            let device = AVCaptureDevice.default(for: AVMediaType.video),
            device.hasTorch
        else { return }

        do {
            try device.lockForConfiguration()
            device.torchMode = on ? .on : .off
            device.unlockForConfiguration()
        } catch {
            print("Torch could not be used")
        }
    }
}

//Add image view properties like this(This is one of the way to add properties).
extension UIImageView {
    //If you want only round corners
    func imgViewCorners() {
        layer.cornerRadius = 10
        layer.borderWidth = 1.0
        layer.masksToBounds = true
    }
}
